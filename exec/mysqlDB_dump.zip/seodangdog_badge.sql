-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: seodangdog-mysql.cza82kskeqwa.ap-northeast-2.rds.amazonaws.com    Database: seodangdog
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `badge`
--

DROP TABLE IF EXISTS `badge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `badge` (
  `badge_seq` int NOT NULL AUTO_INCREMENT,
  `badge_condition` int NOT NULL,
  `badge_description` varchar(50) DEFAULT NULL,
  `badge_img_url` varchar(255) DEFAULT NULL,
  `badge_name` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`badge_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badge`
--

LOCK TABLES `badge` WRITE;
/*!40000 ALTER TABLE `badge` DISABLE KEYS */;
INSERT INTO `badge` VALUES (1,0,'회원가입 시 주어지는 뱃지입니다.','https://seodangdog-s3.s3.ap-northeast-2.amazonaws.com/badges/badge1.png','까막눈'),(2,10,'어휘 문제를 10개 이상 맞힐 경우 뱃지 획득','https://seodangdog-s3.s3.ap-northeast-2.amazonaws.com/badges/badge2.png','어휘왕'),(3,10,'추론 문제를 10개 이상 맞힐 경우 뱃지 획득','https://seodangdog-s3.s3.ap-northeast-2.amazonaws.com/badges/badge3.png','추론왕'),(4,10,'판단 문제를 10개 이상 맞힐 경우 뱃지 획득','https://seodangdog-s3.s3.ap-northeast-2.amazonaws.com/badges/badge4.png','판단왕'),(5,10,'요약까지 완료한 뉴스 갯수가 10개 이상일 경우 뱃지 획득','https://seodangdog-s3.s3.ap-northeast-2.amazonaws.com/badges/badge5.png','요약왕'),(6,20,'뉴스를 20개 이상 읽을 경우 뱃지 획득','https://seodangdog-s3.s3.ap-northeast-2.amazonaws.com/badges/badge6.png','뉴스왕'),(7,20,'단어 게임에서 단어를 20개 이상 맞힐 경우 뱃지 획득','https://seodangdog-s3.s3.ap-northeast-2.amazonaws.com/badges/badge7.png','퀴즈왕');
/*!40000 ALTER TABLE `badge` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:57:48
