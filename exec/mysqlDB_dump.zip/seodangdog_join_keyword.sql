-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: seodangdog-mysql.cza82kskeqwa.ap-northeast-2.rds.amazonaws.com    Database: seodangdog
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `join_keyword`
--

DROP TABLE IF EXISTS `join_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `join_keyword` (
  `join_keyword_seq` int NOT NULL,
  `keyword` varchar(255) NOT NULL,
  PRIMARY KEY (`join_keyword_seq`),
  UNIQUE KEY `UK_b33aj867lts06vlyr7pewckoh` (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `join_keyword`
--

LOCK TABLES `join_keyword` WRITE;
/*!40000 ALTER TABLE `join_keyword` DISABLE KEYS */;
INSERT INTO `join_keyword` VALUES (45,'감기'),(10,'개발자'),(31,'경제성장률'),(32,'경찰'),(59,'과학'),(55,'국내'),(56,'국회'),(58,'국회의원'),(37,'남자친구'),(3,'디즈니'),(17,'딸기'),(24,'마트'),(43,'메모리'),(39,'무역'),(29,'물가'),(42,'반도체'),(46,'배터리'),(15,'베스트셀러'),(12,'복지'),(11,'볼링'),(7,'비트코인'),(9,'사랑'),(6,'사이버범죄'),(13,'삼성'),(57,'선거'),(19,'성공'),(21,'세금'),(30,'소속사'),(14,'손흥민'),(5,'송하윤'),(27,'수험생'),(22,'아기'),(35,'아메리카노'),(60,'아이폰'),(51,'애플'),(36,'여자친구'),(48,'연구'),(52,'연애'),(28,'연예'),(16,'영국'),(53,'영화'),(2,'울산'),(20,'유튜버'),(26,'인스타그램'),(18,'인종차별'),(41,'전염병'),(50,'지역'),(47,'지진'),(8,'총선'),(33,'충주시'),(1,'카리나'),(44,'컨설턴트'),(34,'컴퓨팅'),(40,'코로나'),(23,'코코넛'),(49,'특가'),(25,'편의점'),(4,'학폭'),(54,'해외'),(38,'현대');
/*!40000 ALTER TABLE `join_keyword` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:57:45
